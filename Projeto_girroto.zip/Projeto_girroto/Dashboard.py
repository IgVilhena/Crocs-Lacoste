"""
Abra: http://127.0.0.1:8051
"""

import os
import numpy as np
import pandas as pd

import dash
from dash import Dash, html, dcc, Input, Output, State
import plotly.express as px

from sklearn.linear_model import LinearRegression
from scipy import stats

CSV_PATH = "pokedex_clean_tratado.csv"
NUM_COLS = ['height','weight','hp','attack','defense','s_attack','s_defense','speed']
FEATURE_BASE = [
    "height","weight","hp","attack","defense","s_attack","s_defense",
    "total_stats","phys_density","atk_def_ratio","sp_atk_def_ratio","is_multi_type"
]
EDA_NUM_OPTIONS = [
    'height','weight','hp','attack','defense','s_attack','s_defense','speed',
    'total_stats','phys_density','atk_def_ratio','sp_atk_def_ratio'
]

def _safe_median(s):
    try:
        return float(np.nanmedian(s.astype(float)))
    except Exception:
        return 0.0

def preprocess(df_raw: pd.DataFrame):
    df = df_raw.copy()

    if 'primary_type' not in df.columns:
        if 'type' in df.columns and df['type'].astype(str).str.contains(',').any():
            s = df['type'].astype(str).str.split(',', n=1, expand=True)
            df['primary_type']   = s[0].str.strip().str.lower()
            df['secondary_type'] = s[1].str.strip().str.lower() if s.shape[1] > 1 else np.nan
        else:
            df['primary_type']   = (df['type'] if 'type' in df.columns else np.nan)
    if 'secondary_type' not in df.columns:
        df['secondary_type'] = np.nan

    for c in NUM_COLS:
        if c not in df.columns:
            df[c] = np.nan

    df['total_stats']      = df[['hp','attack','defense','s_attack','s_defense','speed']].sum(axis=1, min_count=1)
    df['phys_density']     = df['weight'] / df['height'].replace(0, np.nan)
    df['atk_def_ratio']    = df['attack'] / df['defense'].replace(0, np.nan)
    df['sp_atk_def_ratio'] = df['s_attack'] / df['s_defense'].replace(0, np.nan)
    df['is_multi_type']    = (~df['secondary_type'].isna()).astype(int)

    df = df.replace([np.inf, -np.inf], np.nan)

    for c in df.select_dtypes(include=[np.number]).columns:
        if df[c].isna().any():
            df[c] = df[c].fillna(_safe_median(df[c]))
    for c in df.select_dtypes(include=['object']).columns:
        if df[c].isna().any():
            df[c] = df[c].fillna(df[c].mode().iat[0])

    df['primary_type'] = df['primary_type'].astype(str).str.lower()

    top_types = df['primary_type'].value_counts().head(8).index.tolist()
    dummies = pd.get_dummies(
        df['primary_type'].where(df['primary_type'].isin(top_types), 'other'),
        prefix='ptype', drop_first=True
    )

    df_model = pd.concat([
        df[[
            "height","weight","hp","attack","defense","s_attack","s_defense","total_stats",
            "phys_density","atk_def_ratio","sp_atk_def_ratio","is_multi_type","speed","primary_type"
        ]],
        dummies
    ], axis=1)

    return df, df_model, top_types

def load_initial_df():
    if CSV_PATH and os.path.exists(CSV_PATH):
        df_raw = pd.read_csv(CSV_PATH)
        return preprocess(df_raw)
    return None, None, []

app = Dash(__name__, suppress_callback_exceptions=True)
app.title = "Dashboard"

df0, dfm0, top0 = load_initial_df()

def df_to_json(df):
    if df is None:
        return ""
    return df.to_json(date_format='iso', orient='split')

def json_to_df(s):
    if not s:
        return None
    return pd.read_json(s, orient='split')

app.layout = html.Div([
    html.H2("Dashboard"),
    html.Div(f"Fonte de dados: {CSV_PATH}"),

    dcc.Store(id='store-df',  data=df_to_json(df0)),
    dcc.Store(id='store-dfm', data=df_to_json(dfm0)),

    html.Hr(),

    html.Div(id='filters-panel'),

    html.Hr(),

    dcc.Tabs(id='tabs', value='tab-eda', children=[
        dcc.Tab(label='EDA', value='tab-eda', children=[

            html.Div([
                html.Div([html.Label("Eixo X"),
                          dcc.Dropdown(id='eda-x',
                                       options=[{'label':c, 'value':c} for c in EDA_NUM_OPTIONS],
                                       value='attack',
                                       clearable=False)],
                         style={'maxWidth':'260px'}),
                html.Div([html.Label("Eixo Y"),
                          dcc.Dropdown(id='eda-y',
                                       options=[{'label':c, 'value':c} for c in EDA_NUM_OPTIONS],
                                       value='defense',
                                       clearable=False)],
                         style={'maxWidth':'260px'}),
            ], style={'display':'flex','gap':'20px','flexWrap':'wrap','margin':'10px'}),

            html.Div([
                html.Div([dcc.Graph(id='hist-speed')],          style={'margin': '10px'}),
                html.Div([dcc.Graph(id='box-speed')],           style={'margin': '10px'}),
                html.Div([dcc.Graph(id='scatter-total-speed')], style={'margin': '10px'}),
                html.Div([dcc.Graph(id='scatter-dyn')],         style={'margin': '10px'}),
            ])
        ]),
        dcc.Tab(label='Previsão', value='tab-pred', children=[
            html.Div(id='predict-panel',  style={'margin':'10px'}),
            html.Div(id='predict-output', style={'margin':'10px', 'fontWeight':'bold'})
        ]),
        dcc.Tab(label='Testes', value='tab-tests', children=[
            html.Div(id='tests-panel', style={'margin':'10px'}),
            html.Pre(id='tests-output', style={'whiteSpace':'pre-wrap', 'margin':'10px'})
        ]),
    ]),
], style={'maxWidth':'1200px','margin':'auto',
          'fontFamily':'system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto'})

def make_filter_layout(df):
    if df is None or df.empty:
        return html.Div("Carregue dados para ver os filtros.")
    types = sorted(df['primary_type'].dropna().unique().tolist())
    return html.Div([
        html.Div([
            html.Label("Tipos dos Pokemons"),
            dcc.Dropdown(
                id='types-select',
                options=[{'label':t, 'value':t} for t in types],
                value=types[:3],
                multi=True,
                placeholder="Selecione tipos",
                style={'maxWidth':'400px'}
            )
        ])
    ])

def apply_mask(df, mask_params):
    if df is None or df.empty:
        return df
    types = mask_params.get('types', [])
    mask = df['primary_type'].isin(types) if types else pd.Series(True, index=df.index)
    return df[mask]

@app.callback(
    Output('filters-panel', 'children'),
    Input('store-df', 'data')
)
def show_filters(df_json):
    df = json_to_df(df_json)
    return make_filter_layout(df)

@app.callback(
    Output('hist-speed','figure'),
    Output('box-speed','figure'),
    Output('scatter-total-speed','figure'),
    Input('store-df','data'),
    Input('types-select','value'),
)
def update_eda(df_json, types):
    df = json_to_df(df_json)
    if df is None or df.empty:
        return px.histogram(), px.box(), px.scatter(), px.imshow(np.zeros((1,1)))
    sel = apply_mask(df, {'types': types or []})
    if sel.empty:
        return px.histogram(), px.box(), px.scatter(), px.imshow(np.zeros((1,1)))
    fig1 = px.histogram(sel, x='speed', nbins=30, title='Distribuição de Speed')
    fig2 = px.box(sel, x='primary_type', y='speed', title='Speed por Tipo')
    fig2.update_layout(xaxis={'categoryorder':'total descending'})
    fig3 = px.scatter(sel, x='total_stats', y='speed', trendline='ols',
                      hover_data=['primary_type'], title='Speed vs Total Stats')
    return fig1, fig2, fig3

@app.callback(
    Output('scatter-dyn','figure'),
    Input('store-df','data'),
    Input('types-select','value'),
    Input('eda-x','value'),
    Input('eda-y','value'),
)
def update_scatter_dyn(df_json, types, xvar, yvar):
    df = json_to_df(df_json)
    if df is None or df.empty or xvar is None or yvar is None:
        return px.scatter()
    sel = apply_mask(df, {'types': types or []})
    if sel.empty:
        return px.scatter()
    fig = px.scatter(
        sel, x=xvar, y=yvar, color='primary_type',
        trendline='ols', hover_data=['primary_type'],
        title=f'{yvar} vs {xvar} (por tipo)'
    )
    return fig

@app.callback(
    Output('predict-panel','children'),
    Input('store-dfm','data')
)
def build_predict_panel(dfm_json):
    dfm = json_to_df(dfm_json)
    if dfm is None or dfm.empty:
        return html.Div("Carregue dados.")

    controls = []
    for col, stp in [('hp',1),('attack',1),('defense',1)]:
        lo, hi = int(dfm[col].min()), int(np.ceil(dfm[col].max()))
        val = int(np.nanmedian(dfm[col]))
        controls.append(
            html.Div([
                html.Label(col),
                dcc.Slider(
                    id=f'pred-{col}', min=lo, max=hi, step=stp, value=val,
                    marks=None, tooltip={'always_visible': False}, updatemode='drag'
                )
            ], style={'marginBottom':'12px'})
        )

    types = sorted(dfm['primary_type'].unique().tolist())
    controls = [html.Div([
        html.Label('primary_type'),
        dcc.Dropdown(
            id='pred-type',
            options=[{'label':t,'value':t} for t in types],
            value=types[0],
            style={'maxWidth':'320px'}
        )
    ], style={'marginBottom':'12px'})] + controls

    controls.append(html.Button("Prever speed", id='btn-predict', style={'marginTop':'8px'}))
    return html.Div(controls, style={'maxWidth':'700px'})

@app.callback(
    Output('predict-output','children'),
    Input('btn-predict','n_clicks'),
    State('store-dfm','data'),
    State('types-select','value'),
    State('pred-type','value'),
    State('pred-hp','value'),
    State('pred-attack','value'),
    State('pred-defense','value'),
    prevent_initial_call=True
)
def do_predict(n_clicks, dfm_json, types, ptype, hpv, atkv, defv):
    if not n_clicks:
        raise dash.exceptions.PreventUpdate
    dfm = json_to_df(dfm_json)
    if dfm is None or dfm.empty:
        return "Carregue dados."

    sel = apply_mask(dfm, {'types': types or []}).dropna(subset=['speed'])
    if len(sel) < 30:
        return "Dados insuficientes."

    X = sel[['hp','attack','defense'] + [c for c in sel.columns if c.startswith('ptype_')]].copy()
    y = sel['speed'].values
    lr = LinearRegression().fit(X, y)

    row = {'hp': hpv, 'attack': atkv, 'defense': defv}
    x_row = pd.DataFrame([row])

    for c in X.columns:
        if c.startswith('ptype_'):
            x_row[c] = 0
    for c in X.columns:
        if c.startswith('ptype_') and ptype == c.replace('ptype_',''):
            x_row[c] = 1

    x_row = x_row[X.columns]
    y_hat = float(lr.predict(x_row)[0])
    y_hat = max(0, y_hat)
    return f"Velocidade prevista: {y_hat:.2f}"

@app.callback(
    Output('tests-panel','children'),
    Input('store-df','data')
)
def build_tests_panel(df_json):
    df = json_to_df(df_json)
    if df is None or df.empty:
        return html.Div("Carregue dados.")
    types = sorted(df['primary_type'].unique().tolist())
    default_b = types[1] if len(types) > 1 else types[0]
    return html.Div([
        html.Div([
            html.Label('Grupo A'),
            dcc.Dropdown(id='test-a',
                options=[{'label':t,'value':t} for t in types],
                value=types[0], style={'maxWidth':'300px','marginBottom':'12px'})
    ]),
        html.Div([
            html.Label('Grupo B'),
            dcc.Dropdown(id='test-b',
                options=[{'label':t,'value':t} for t in types],
                value=default_b, style={'maxWidth':'300px','marginBottom':'12px'})
    ]),
        html.Div([
            html.Label('Variável'),
            dcc.Dropdown(id='test-var',
                options=[{'label':v,'value':v}
                    for v in ['hp','attack','defense','s_attack','s_defense','speed','total_stats']],
                value='speed', style={'maxWidth':'300px','marginBottom':'12px'})
    ]),
        html.Button("Rodar teste", id='btn-test', style={'marginTop':'10px'})
])

def bootstrap_ci_diff(a, b, n_boot=2000, alpha=0.05, seed=42):
    rng = np.random.default_rng(seed)
    na, nb = len(a), len(b)
    diffs = []
    for _ in range(n_boot):
        sa = rng.choice(a, size=na, replace=True)
        sb = rng.choice(b, size=nb, replace=True)
        diffs.append(np.mean(sa) - np.mean(sb))
    diffs = np.sort(diffs)
    lo = np.percentile(diffs, 100*alpha/2)
    hi = np.percentile(diffs, 100*(1-alpha/2))
    return float(lo), float(hi)

@app.callback(
    Output('tests-output','children'),
    Input('btn-test','n_clicks'),
    State('store-df','data'),
    State('types-select','value'),
    State('test-a','value'),
    State('test-b','value'),
    State('test-var','value'),
    prevent_initial_call=True
)
def run_test(n_clicks, df_json, types, a_type, b_type, var):
    if not n_clicks:
        raise dash.exceptions.PreventUpdate
    df = json_to_df(df_json)
    if df is None or df.empty:
        return "Carregue dados."

    sel = apply_mask(df, {'types': types or []})
    a = sel.loc[sel['primary_type']==a_type, var].dropna().values
    b = sel.loc[sel['primary_type']==b_type, var].dropna().values
    if len(a) < 3 or len(b) < 3:
        return "Amostras insuficientes para o teste."

    t, p = stats.ttest_ind(a, b, equal_var=False)
    lo, hi = bootstrap_ci_diff(a, b, n_boot=3000, alpha=0.05)
    sig = "✅ Diferença significativa." if p < 0.05 else "ℹ️ Não rejeitamos H0."
    return f"t = {t:.4f} | p-valor = {p:.4g}\nIC95% para diferença = ({lo:.3f}, {hi:.3f})\n{sig}"

if __name__ == "__main__":
    app.run(debug=False, host="127.0.0.1", port=8051, use_reloader=False)
